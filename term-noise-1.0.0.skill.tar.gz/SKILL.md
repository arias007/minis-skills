---
name: term-noise
description: 诊断并消除 Minis 终端里刷屏的 "proot info: native_offload ..." 噪音。当用户抱怨终端刷屏、打不进字、或后台服务周期性调用 android-* 工具时使用。含根因说明（重定向为什么拦不住）、定位脚本、以及让服务尊重静音标志的改法。
version: 1.0.0
---
# 终端刷屏 (proot info: native_offload) 诊断与消除

## 什么时候用

- 用户说终端"刷屏""黑屏打不进字""一直滚东西"
- 看到 `proot info: native_offload: offloaded 'android-xxx' → tmpfile=... exit=N`
- 改了服务输出重定向但**照样刷屏**

## ★★ 第一件事：别试重定向，它拦不住

```
cmd >/dev/null 2>&1   # 照样打印 proot info
```

这行不是被调用命令写的，是 **PRoot 的 native-offload 机制**在每次执行 `android-*` 工具时，
直接写给**承载会话的那个 shell 层**（`/dev/tty`）。所以「关掉调用方的 stdout/stderr」永远是死路。

## 排查三步

### 1. 量化噪音频率
```sh
ls /tmp/.native-offload-* | wc -l    # 隔一分钟再数一次，差值 = 每分钟噪音行数
```

### 2. 抓现行（文件名带 pid + 序号，内容能认出是哪个工具）
```sh
f=$(ls -t /tmp/.native-offload-* | head -1); cat "$f"
```
| 内容特征 | 是哪个工具 |
|---|---|
| `{"tasks":[...]}` | `minis-scheduled list` |
| `{"error":"clipboard_requires_foreground"}` | `android-clipboard get` |
| 含 `title`/`body` | `android-notification` |

### 3. 找**循环**，不要一个个关服务

**最隐蔽的坑**：某个 ensure 脚本每分钟误判"服务挂了"→ 又 fork 一个 → 新进程绑不上端口
→ 空转 15 次重试再退出。而这个启动流程每轮都调一次 android 工具 = **每分钟稳定一行噪音**。

观察日志里的重试痕迹：
```sh
tail -40 /tmp/inboxd.log      # 找 "bind attempt N failed" / "Address in use"
```

## 三类真正的修法

### A. 端口被占就静默退出（治本，最能降噪）
Python 服务绑定失败时不要空转重试：
```python
except OSError as e:
    if getattr(e, 'errno', None) == 98:      # EADDRINUSE
        sys.stderr.write("port busy, another instance is running — exit\n")
        return 0                             # 立刻退，别 sleep 重试
```

### B. 把会调 android 工具的初始化挪到"确认自己是唯一实例"之后
```python
# 错：先 cleanup_orphans()（内部调 minis-scheduled list）再 bind
# 对：bind 成功 → 确认独占 → 再做 cleanup
```
否则每次「白启动」都白打一行噪音。

### C. 终端开着时自动降频（保留功能，只是慢）
```python
def tty_in_use():
    """扫 /proc/*/fd 找 /dev/pts/* —— 有交互 shell 挂在 pty 上就说明终端开着"""
    for pid in [d for d in os.listdir('/proc') if d.isdigit()]:
        try:
            for fd in os.listdir('/proc/%s/fd' % pid):
                if '/dev/pts/' in os.readlink('/proc/%s/fd/%s' % (pid, fd)):
                    return True
        except Exception:
            continue
    return False
```
轮询循环里：`iv = 60 if tty_in_use() else 2`（实测 66 行/分 → 1 行/分）。

### D. 让所有 ensure 尊重一个静音标志
```sh
# ensure 脚本开头：
[ -f /tmp/.quiet-on ] && exit 0
```
否则用户手动停了服务，crontab 一分钟后又被拉回来，「静音」形同虚设。

## ★ 附带必查：`/proc` 在 PRoot 里不可信

| 想读 | 结果 |
|---|---|
| `/proc/<pid>` 的 mtime | **恒等于"现在"**（每次读都在变）→ 用它判断"代码比进程新"会永远为真，导致每分钟误杀重启 |
| `/proc/uptime`、`/proc/stat` | Permission denied |
| `/proc/<pid>/stat` 的 starttime | 读得到，但算不出墙上时间（上一条读不到） |

**替代方案**：让服务自己在启动时写时间戳文件（如 `/tmp/svc.started`），外部只比这个文件与源码 mtime。

## 验证

```sh
# 静默态：清零服务 + 等 ≥75 秒（跨过 crontab 一分钟周期）→ 应无复活
pkill -f "目标服务"; sleep 75
ps -ef | grep "目标服务" | grep -v grep || echo "✓ 未复活"
```

## 坑

- `pkill -f` 别用裸文件名（`serve.py` 会误杀 `dashboard/serve.py`），按完整路径匹配
- grep 检查进程写 `grep "x\.py" | grep -v grep`；写成 `grep "[x]\.py"` 在双引号里正则可能报 bad character range
- 测「静默是否被 crontab 破坏」必须等满 70 秒以上，且清零后再开始计时
